<footer class="footer">
	<div class="container">
		<div class="pull-right partner-logo-header">
			<img src="img/partner-logo-header.png"/>
		</div>
		<div class="navbar navbar-default">
	      <ul class="nav navbar-nav">
          <li class="active"><a href="#">Home</a></li>
          <li><a href="#contact">Contact Us</a></li>
          <!--<li><a href="#translate">Translate</a></li>
          <li><a href="#twitter">Twitter</a></li>
          <li><a href="#rss">RSS</a></li>-->
	      </ul>
    </div>
	</div>
</footer>

		<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
		<script src="js/twitter-bootstrap-hover-dropdown.min.js"></script>
		<script type="text/javascript">
			$("body").tooltip({
				selector: "a[rel=tooltip]"
			});
		</script>
				<script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
		<script src="js/bootstrap-image-gallery.min.js"></script>
  </body>
</html>
