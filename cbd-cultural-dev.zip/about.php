<?php include 'header-inner.php'; ?>
			<div class="col-lg-3 sidebar">
				<?php include 'inner-nav.php'; ?>
			</div>
			<div class="col-lg-9">
				<h1>About the Joint Programme</h1>
				<p>The Joint Programme between UNESCO and the CBD Secretariat (SCBD) was developed at the <a href="http://www.cbd.int/meetings/icbcd" alt="International Conference on Biological and Cultural Diversity">International Conference on Biological and Cultural Diversity</a>, held in Montreal, Canada in 2010. It was endorsed by UNESCO’s constituencies and welcomed by the 10th meeting of the Parties to the CBD (CBD COP 10) held in October 2010 in Nagoya, Japan (Decision X/20).</p>
				<p>CBD COP 10 recognized the Joint Programme as a <a href="https://www.cbd.int/decision/cop/default.shtml?id=12286" alt="Decision X/20">‘useful co-ordination mechanism to advance the implementation of the Convention and deepen global awareness of the interlinkages between cultural and biological diversity’</a>. State Parties and other relevant stakeholders were invited to ‘contribute to and support the implementation of this joint programme’.</p>
				<div style="text-align:center"><img src="img/landscape.png" alt="Objectives" /></div>
				<h2>KEY OBJECTIVES</h2>
				<p>With the Convention on Biological Diversity (CBD) acting as global focal point for biodiversity and UNESCO acting as global focal point for cultural diversity, the two Institutions launched a Joint Programme in 2010 to:</p>
				<ol>
					<li>Build bridges between ongoing work on biodiversity and cultural diversity.
					<li>Promote synergies and information sharing among already existing programmes, projects and activities.</li>
					<li>Further explore conceptual and methodological issues related to the links between biological and cultural diversity and the role of indigenous peoples and local communities in enhancing those links.</li>
					<li>Promote the collection, compilation and analysis of information from on-the ground activities linking biological and cultural diversity from, among others, biosphere reserves and World Heritage sites, and from the experiences provided by indigenous peoples and local communities.</li>
					<li>Support and foster learning networks on bio-cultural approaches, linking grassroots and community initiatives with local, national, regional and global policy processes.</li>
					<li>Raise awareness about the importance of biological and cultural diversity in resource management and decisionmaking processes as well as for the resilience of socioecological systems.</li>
				</ol>
					<div style="text-align:center"><img src="img/objectives.png" alt="Objectives" /></div>		
					<h2>INFORMAL DIVERSITY LIAISON GROUP</h2>
					<p>The main objective of the informal Liaison Group on Biological and Cultural Diversity (DLG) is to provide technical advice in view of assisting the Secretariats of CBD and UNESCO in advancing the Joint Programme, assessing the progress made and providing guidance for next steps.</p>
					<p>The members of the DLG were invited by CBD Executive Secretary and UNESCO Assistant Director General for Natural Sciences to participate in the liaison group, based on expertise, ability to contribute to the deeper understanding of the interface between biological and cultural diversity, taking into account gender considerations and geographic balance.</p>
					<p>The group is meeting on an ad-hoc basis, subject to the availability of funding, as well as electronically.</p>
					<p>The first meeting of DLG was held in New York in April 2012. The <a href="https://www.cbd.int/doc/meetings/cop/cop-11/information/cop-11-inf-11-en.pdf">report</a> was considered by CBD COP 11 resulting in Decision (check with JOHN).</p>
			</div>
		</div>

<?php include 'footer.php'; ?>
