<?php include 'header-inner.php'; ?>
			<div class="col-lg-3 sidebar">
				<?php include 'inner-nav.php'; ?>
			</div>
			<div class="col-lg-9">
				<h1>Challenges and opportunities </h1>
				<p>Dual approach to biological and cultural diversity has led to varying interests within the same location, different competencies and designated domains of authority, different instruments policies, tools, and legal frameworks, different understandings of diversity among responsible authorities, and the different international movements dealing with biological and cultural diversity through individual agendas.</p>
				<div class="panel-group" id="accordion">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-1">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
								Different approaches consider biological and cultural diversity separately
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in">
							<div class="panel-body">
								<p>Separating biological from cultural diversity results in differing and sometimes conflicting agendas and approaches. From biodiversity perspective, people may be perceived as a disturbance or even a threat. From the cultural diversity perspective, more attention is given to individual cultural artifacts and cultural heritage disconnected from natural environment. Viewing biological and cultural diversity as separate entities can sever the historic and in many cases mutually reinforcing relationship between biodiversity and local cultural practices, land uses, languages and associated knowledge. </p>
								<p class="solutions">A joint approach to promotion of diversity would strengthen the integration, interdependence and positive relationship between cultural and biological diversity.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-2">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
									Different sectors often have different interests within the same location
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Sites of both cultural and natural distinctiveness may be of interest to various sectors. Different sectors may not see eye to eye regarding which management practices to employ at a site of both cultural and biodiversity importance, even when they both want what is best for that area. </p> 
								<p class="solutions">A joint management plan would balance both biodiversity and cultural heritage in equal measure.</p>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-3">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
								Different administrative sectors have different competencies and designated domains of authority
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Decision makers operate from different administrative sectors such as natural resources management, agriculture, cultural heritage and historic preservation, sustainable development, planning, civil engineering, tourism, economics, etc. </p>
								<p>This governmental organization scheme leads to different administrative concerns and values. This situation results in an ongoing debate over contrasting ideas of what constitutes diversity (biological and cultural) and how to best manage it. </p>
								<p class="solutions">A joint approach would allow a full appreciation of the interplay between biological and cultural diversity, social and natural dynamics, at a given site and would integrate the specialized knowledge and various interests across multiple various sectors.</p>
											</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-4">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
								Different instruments (policies, tools, and legal frameworks) exist for the promotion of biodiversity and cultural diversity 
								</a>
							</h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Across various levels of society, existing biodiversity policies tend to focus more on the categories of habitat protection and individual species protection. In parallel, cultural diversity policies tend to focus on either monument protection (which is valued for its archaeological, architectural, historical, folk, technical, art elements) or protection based on a site’s heritage value (which includes intangible elements such as seasonal customs, family traditions, crafts, folklore, food, clothing, and dance). </p>
								<p class="solutions">A joint framework would promote sustainable management, including conservation, of both cultural and biological diversity within a single approach. Such a framework would allow for better communication, cooperation, and coordination among various administrative authorities.</p>
											</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-5">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
								Different responsible authorities have different understanding of diversity
								</a>
							</h4>
						</div>
						<div id="collapseFive" class="panel-collapse collapse">
							<div class="panel-body">
								<p>A lack of information about the relationships between biological and cultural diversity, including cultural and management practices, has resulted to a broadening of the gap between ‘biological’ and ‘cultural’ landscapes. In biodiversity policies, the concepts of conservation, sustainable use and access and benefit sharing are frequently implemented without taking into consideration the positive impact of many local cultural practices, land uses, knowledge and value systems and ways of living together. With regard to cultural policies, opinions vary on what defines culture and its boundaries often excluding a variety of distinctive relations to biodiversity, which underpin the diversity of tangible and intangible cultural heritage, including cultural expressions and practices.</p>
								<p class="solutions">A joint framework would allow for multiplicity of more comprehensive interpretations of diversity.</p>
											</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-6">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
								Different international institutions and instruments deal with biological and cultural diversity separately
								</a>
							</h4>
						</div>
						<div id="collapseSix" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Separately focused conventions or directives encourage the Parties to implement independent agendas dealing with different types of diversity. Although some progress has been made in recent years, international institutions are configured into various Conferences of the Parties, Committees, and Working Groups which tend to work in isolation on separate priorities in biological diversity and diversity.</p>
								<p class="solutions">An enhanced joint framework could bridge concerns within organizations and motivate synthesis between various approaches to diversity.</p>
											</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title bkg-7">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">
								Lack of assessment of “bio-cultural” diversity
								</a>
							</h4>
						</div>
						<div id="collapseSeven" class="panel-collapse collapse">
							<div class="panel-body">
								<p>The concept of “biocultural” diversity and “biocultural” heritage has emerged in recent decade as part of the efforts to narrow the widening nature-culture divide. These concepts provide important starting points for the reflections on the links between biological and cultural diversity, and have proven effective in raising awareness on the inextricable link between biological and cultural diversity, including the diversity of living organisms or habitats whose present features are due to cultural action. However, there is still a lack of consensus on the precise meaning of the term ‘biocultural’ and how it links to diversity agenda(s).</p>
								<p class="solutions">A joint framework would encourage the scientific and practitioner communities to assess the different manifestations and components of “bio-cultural” diversity.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php include 'footer.php'; ?>
