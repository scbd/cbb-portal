<ul class="nav">
	<li><a href="about.php">About the Programme</a>
		<ul>
			<li><a href="legal.php">International legal instruments </a></li>
			<li><a href="step1.php">Interlinked diversity</a></li>
			<li><a href="step2.php">Challenges and opportunities</a></li>
			<li><a href="#">The way forward</a></li>
		</ul>
	</li>
</ul>