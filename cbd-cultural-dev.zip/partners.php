<?php include 'header-inner.php'; ?>
			<!--
				<div class="col-lg-3 sidebar">
					<?php //include 'inner-nav.php'; ?>
				</div>
			-->
			<div class="col-lg-12">
				<h1>Partners of the Joint UNESCO- SCBD Programme on Links between Biological and Cultural Diversity </h1>
<ul>	
	<li><h3>Bioversity International</h3>
	Webpage: <a href="http://www.bioversityinternational.org/">http://www.bioversityinternational.org</a><br/>Mr.  Pablo Eyzaguirre<br/>Email: <a href="mailto:p.eyzaguirre@cgiar.org">p.eyzaguirre@cgiar.org</a></li>
	
	<li><h3>Christensen Fund</h3>Webpage: <a href="http://www.christensenfund.org/">www.christensenfund.org</a><br/>Mr.  Jeffrey Y. Campbell<br/>Email: <a href="mailto:jeff@christensenfund.org">jeff@christensenfund.org</a></li>
	
	<li><h3>Deutsche Gesellschaft für Internationale Zusammenarbeit (GIZ)</h3>
		Webpage: <a href="http://www.giz.de/en">www.giz.de/en</a><br/>Ms.  Barbara Lasen<br/>Email: <a href="mailto:barbara.lassen@giz.de">barbara.lassen@giz.de</a></li>
	
	<li><h3>Equator Initiative, UNDP</h3>Webpage: <a href="http://www.equatorinitiative.org/">www.equatorinitiative.org</a><br/>Ms.  Eileen de Ravin<br/>Email: <a href="mailto:eileen.de.ravin@undp.org">eileen.de.ravin@undp.org</a></li>
	
	<li><h3>FAO and GIAHS- Globally Important Agricultural Heritage Systems</h3>Webpage: <a href="http://www.fao.org/home/en">www.fao.org/home/en</a>  and <a href="http://www.giahs.org/">www.giahs.org</a><br/>Ms MaryJane Ramos de la Cruz,<br/>Email: <a href="mailto:MaryJane.RamosdelaCruz@fao.org">MaryJane.RamosdelaCruz@fao.org</a></li>
	
	<li><h3>Global Diversity Foundation</h3>Webpage: <a href="http://www.global-diversity.org/">www.global-diversity.org</a><br/>Mr.   Gary Martin<br/>Email: <a href="mailto:gary@global-diversity.org">gary@global-diversity.org</a>; <a href="mailto:gmartingdf@gmail.com">gmartingdf@gmail.com</a></li>
	
	<li><h3>ICCA Consortium</h3>Webpage: <a href="http://www.iccaforum.org/">www.iccaforum.org</a><br/>Ms.   Grazia Borrini-Feyerabend<br/>Email: <a href="mailto:gbf@iccaconsortium.org">gbf@iccaconsortium.org</a></li>
	
	<li><h3>International Fund for Agricultural Development (IFAD)</h3>Webpage: <a href="http://www.ifad.org/">www.ifad.org</a><br/>Ms. Antonella Cordone<br/>Email: <a href="mailto:a.cordone@ifad.org">a.cordone@ifad.org</a></li>
	
	<li><h3>International Institute for Environment and Development (IIED)</h3>Webpage: <a href="http://www.iied.org/">www.iied.org</a><br/>Ms.   Krystyna Swiderska<br/>Email: <a href="mailto:krystyna.swiderska@iied.org">krystyna.swiderska@iied.org</a></li>
	
	<li><h3>International Union for Conservation of Nature- IUCN</h3>Webpage: <a href="http://www.iucn.org/">www.iucn.org</a><br/>Mr. Gonzalo Oviedo<br/>Email: <a href="mailto:gonzalo.oviedo@iucn.org">gonzalo.oviedo@iucn.org</a></li>
	
	<li><h3>IPACC Secretariat</h3>Webpage: <a href="http://www.ipacc.org.za/eng">www.ipacc.org.za/eng</a><br/>Mr.  Nigel Crawall<br/>Email: <a href="mailto:crawhall@gmail.com">crawhall@gmail.com</a></li>
	
	<li><h3>Mayan Intercultural University (Mexico)</h3>Webpage: <a href="http://www.uimqroo.edu.mx/">www.uimqroo.edu.mx</a><br/>Mr.  Francisco Rosado-May,<br/>Email: <a href="mailto:fjrmay@hotmail.com">fjrmay@hotmail.com</a>; <a href="mailto:francisco.rosadomay@uimqroo.edu.mx">francisco.rosadomay@uimqroo.edu.mx</a></li>
	
	<li><h3>National Biodiversity Authority</h3>Webpage: <a href="http://www.nbaindia.org/">http://www.nbaindia.org</a><br/>Mr.  Balakrishna Pisupati<br/>Email: <a href="mailto:balapisupati@yahoo.com">balapisupati@yahoo.com</a>; <a href="mailto:chairman@nbaindia.in">chairman@nbaindia.in</a></li>
	
	<li><h3>National Geographic</h3>Webpage: <a href="http://www.nationalgeographic.com/">www.nationalgeographic.com</a><br/>Mr.  David M. Braun<br/>Email: <a href="mailto:dbraun@ngs.org">dbraun@ngs.org</a></li>
	
	<li><h3>Natural Justice</h3>Webpage: <a href="http://naturaljustice.org/">naturaljustice.org</a><br/>Ms.  Johanna Von Braun<br/>Email: <a href="mailto:johanna@naturaljustice.org">johanna@naturaljustice.org</a></li>
	
	<li><h3>PCI Media Impact</h3>Webpage: <a href="http://www.mediaimpact.org/">www.mediaimpact.org</a><br/>Mr.  Sean Southey<br/>Email: <a href="mailto:ssouthey@mediaimpact.org">ssouthey@mediaimpact.org</a></li>
	
	<li><h3>Prodiversatis LAC region (Argentina)</h3>Webpage: <a href="http://www.prodiversitas.bioetica.org/">www.prodiversitas.bioetica.org</a><br/>Ms.  Teodora Zamudio,<br/>Email: <a href="mailto:teodoza@hotmail.com">teodoza@hotmail.com</a></li>
	
	<li><h3>Satoyama Initiative</h3>Webpage: <a href="http://www.ias.unu.edu/">http://www.ias.unu.edu</a> and <a href="http://satoyama-initiative.org/">http://satoyama-initiative.org</a><br/>Mr Wataru Suzuki - Satoyama Initiative Coordinator</li>
	
	<li><h3>Sophia University Graduate School of Global Environmental Studies</h3><a href="http://webpage:%20%20www.genv.sophia.ac.jp/english">Webpage:  www.genv.sophia.ac.jp/english</a><br/>Ms.  Anne McDonald<br/>Email: <a href="mailto:annemcdonald65@gmail.com">annemcdonald65@gmail.com</a></li>
	
	<li><h3>Tebtebba Foundation / Forest Peoples Programme</h3>Webpage: <a href="http://www.tebtebba.org/">www.tebtebba.org</a><br/>Ms.  Joji Carino<br/>Email: <a href="mailto:jojicarino@mac.com">jojicarino@mac.com</a></li>
	
	<li><h3>Terralingua</h3>Webpage: <a href="http://www.terralingua.org/">www.terralingua.org</a><br/>Ms.  Luisa Maffi<br/>Email:<a href="mailto:maffi@terralingua.org">maffi@terralingua.org</a></li>
	
	<li><h3>The Resilience and Development Programme (SwedBio) at Stockholm Resilience Centre</h3>Webpage: <a href="http://www.stockholmresilience.org/">www.stockholmresilience.org</a><br/>Ms.  Pernilla Malmer,<br/>Email: <a href="mailto:pernilla.malmer@stockholmresilience.su.se">pernilla.malmer@stockholmresilience.su.se</a></li>
	
	<li><h3>UNDP Small Grants Programme</h3>Webpage: <a href="http://www.sgp.org.np/">www.sgp.org.np</a><br/>Mr.  Terence Hay-Edie<br/>Email: <a href="mailto:terence.hay-edie@undp.org">terence.hay-edie@undp.org</a></li>
	
	<li><h3>The United Nations Permanent Forum on Indigenous Issues (UNPFII)</h3>Webpage: <a href="http://www.undesadspd.org/">www.undesadspd.org</a> /IndigenousPeoples<br/>Ms.  Mirna Cunningham<br/>Email: <a href="mailto:mirnacunningham@aol.com">mirnacunningham@aol.com</a></li>
	
	<li><h3>United Nations University- Traditional Knowledge Centre</h3>Webpage:<a href="http://www.unutki.org/">www.unutki.org</a><br/>Mr.  Gleb Raygorodetsky<br/>Email:<a href="mailto:kibii@me.com">kibii@me.com</a>; <a href="mailto:raygorodetsky@ias.unu.edu">raygorodetsky@ias.unu.edu</a></li>
	
	<li><h3>University of Montreal</h3>Webpage: <a href="http://www.umontreal.ca/english">www.umontreal.ca/english</a><br/>Ms.  Thora Herrmann,<br/>Email:<a href="mailto:thora.martina.herrmann@umontreal.ca">thora.martina.herrmann@umontreal.ca</a></li>
	
	<li><h3>University of Rome-La Sapienza (CUEIM)</h3>Webpage: <a href="http://www.coursera.org/sapienza">www.coursera.org/sapienza</a><br/>Mr.   Pier Luigi Petrillo<br/>Email: <a href="mailto:pierluigi.petrillo@unitelma.it">pierluigi.petrillo@unitelma.it</a></li>
	
	
	<li><h3>University of São Paulo (and University of Chicago)</h3>Webpage: <a href="http://www5.usp.br/en"> www5.usp.br/en</a><br/>Ms.   Manuela Carneiro da Cunha (Professor emerita)<br/>Email: <a href="mailto:mcarneir@uchicago.edu">mcarneir@uchicago.edu</a></li>
	
	<li><h3>University of Florence (Italy)</h3>Webpage: <a href="http://www.unifi.it/mdswitch.html">www.unifi.it/mdswitch.html</a><br/>Mr.  Mauro Agnoletti,<br/>Email: <a href="mailto:mauro.agnoletti@unifi.it">mauro.agnoletti@unifi.it</a></li>
	
	<li><h3>U.S. Forest Service &amp; International Union of Forest Research Organizations</h3>Webpage: <a href="http://iufro2014.com/">http://iufro2014.com</a><br/>Mr.  John Parotta<br/>Email: <a href="mailto:jparrotta@fs.fed.us">jparrotta@fs.fed.us</a></li>
	
	<li><h3>World Agricultural Heritage Foundation (WAFH)</h3>Mr.  Parviz Koohafkan<br/>Email: <a href="mailto:parvizkoohafkan@gmail.com">parvizkoohafkan@gmail.com</a></li>
</ul>
			</div>
		</div>
	</div>

<?php include 'footer.php'; ?>
