<?php include 'header-inner.php'; ?>
			<div class="col-lg-3 sidebar">
				<?php include 'inner-nav.php'; ?>
			</div>
			<div class="col-lg-9">
				<h1>International legal instruments </h1>
				<p>There is increasing recognition of the importance of cultural diversity when dealing with biological diversity. At the same time, consensus is growing regarding the role of biodiversity in actions to promote cultural diversity. This calls for enhanced synergies and better coordination in the implementation of existing biodiversity and cultural diversity international agreements. </p>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/cbd.gif" alt="...">
					</a>
					<div class="media-body">
						<h3>Convention on Biological Diversity (CBD)</h3>
						<p>The objectives of the CBD are the conservation of biological diversity, the sustainable use of its components, and the fair and equitable sharing of the benefits arising from commercial and other utilization of genetic resources. The agreement covers all ecosystems, species, and genetic resources. More http://www.cbd.int/</p>
					</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/heritage.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>World Heritage Convention (WHC)</h3>
				<p>The primary mission of the WHC is to identify and conserve the world's cultural and natural heritage, by drawing up a list of sites whose outstanding values should be preserved for all humanity and to ensure their protection through a closer co-operation among nations. More http://whc.unesco.org/</p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/diversity.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Universal Declaration on Cultural Diversity</h3>
				<p>Adopted by the General Conference of UNESCO in 2001, this Declaration is constituted by 12 Articles; Article 1 titled "Cultural diversity, the common heritage of humanity" states that "As a source of exchange, innovation and creativity, cultural diversity is as necessary for humankind as biodiversity is for the nature. More http://unesdoc.unesco.org/images/0012/001271/127160m.pdf</p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/unesco.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Convention for the Safeguarding of Intangible Cultural Heritage</h3>
				<p>The key objectives of this Convention are to safeguard and ensure respect for the intangible cultural heritage of the communities, groups and individuals concerned. The “intangible cultural heritage”, is manifested inter alia in the domains of knowledge and practices concerning nature and the universe; oral traditions and expressions; performing arts; social practices, rituals and festive events and traditional craftsmanship. More http://www.unesco.org/culture/ich/index.php?lg=en&pg=00006</p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/cppdce.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Convention on the Protection and Promotion of the Diversity of Cultural Expressions</h3>
				<p>Ensures artists, cultural professionals, practitioners and citizens worldwide can create, produce, disseminate and enjoy a broad range of cultural goods, services and activities, including their own.  More http://www.unesco.org/new/en/culture/themes/cultural-diversity/diversity-of-cultural-expressions/the-convention/convention-text/ </p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/cites.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Convention on International Trade in Endangered Species of Wild Fauna and Flora (CITES)</h3> 
				<p>The Convention aims to ensure that international trade in specimens of wild animals and plants does not threaten their survival. Through its three appendices, the Convention accords varying degrees of protection to more than 30,000 plant and animal species. More http://www.cites.org/</p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/cms.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Convention on the Conservation of Migratory Species of Wild Animals (CMS)</h3>
				<p>The CMS, or the Bonn Convention aims to conserve terrestrial, marine and avian migratory species throughout their range. Parties to the CMS work together to conserve migratory species and their habitats by providing strict protection for the most endangered migratory species, by concluding regional multilateral agreements for the conservation and management of specific species or categories of species, and by undertaking co-operative research and conservation activities. More http://www.cms.int/</p>
				</div>
				</div>
				<div class="media">
					<a class="pull-left" href="#">
						<img class="media-object" src="img/ramsar.gif" alt="...">
					</a>
					<div class="media-body">
				<h3>Convention on Wetlands (the Ramsar Convention)</h3>
				<p>The Ramsar Convention provides the framework for national action and international cooperation for the conservation and wise use of wetlands and their resources. The convention covers all aspects of wetland conservation and wise use, recognizing wetlands as ecosystems that are extremely important for biodiversity conservation in general and for the well-being of human communities. More http://www.ramsar.org/cda/en/ramsar-home/main/ramsar/1_4000_0__</p>
				</div>
				</div>
				</div>
			</div>
		</div>

<?php include 'footer.php'; ?>
